﻿using System.ComponentModel.DataAnnotations;

namespace GestionBibilotequeEnLinge.Models
{
    public class Category
    {
        public int Id { get; set; }

        [MaxLength(255)] // Limite valide pour MySQL
        public string Name { get; set; }
    }
}
